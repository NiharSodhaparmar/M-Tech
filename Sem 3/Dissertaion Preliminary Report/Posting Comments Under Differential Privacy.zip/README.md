# SVNIT M.Tech Dissertation Report
It's an M.Tech dissertation report for SVNIT (NIT Surat) in LaTex format. 

Below are the steps of how to use this report:

Step 1: Download and Install:

1) Miktex - http://miktex.org/download
2) Texstudio editor - http://www.texstudio.org/

Step 2: Compile and Run

Goto Options -> Configure TexStudio -> Build 
Set Default compiler: XeLatex
Set Default Bibliography Tool: BibTex

Notes:
------
1. Please check generated pdf twice . . . The output may be different than expected . . .
2. Use Dissertation Preliminaries word instead of Dissertation, if you are using this report format for your 3rd sem. presentation

Thanks to Milind Padalkar (@mgpadalkar) for making report format for PhD students . . . I have modified Milind Padlkar's report format for SVNIT M.Tech students.

For any queries, create issue . . .

Enjoy . . . :) :)
